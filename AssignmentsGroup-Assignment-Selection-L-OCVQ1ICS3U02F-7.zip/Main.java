//Love Finder Project
//Bryan, Carson
//2/25/2021
//Brief Description: 

class Main {
		//Furthest Lat Long Values from image
		static final double LAT_NORTH = 45.53734, LON_NORTH = -75.33966;
		static final double LAT_SOUTH = 44.96257,	LON_SOUTH = -75.81984;	
		static final double LAT_EAST = 45.36463, LON_EAST = -75.24643;  
		static final double LAT_WEST = 45.41020, LON_WEST = -76.35398;  

		//Declare Variables
		static double lat1 = LAT_WEST; 
		static double lon1 = LON_WEST; 
		static double lat2 = LAT_SOUTH; 
		static double lon2 = LON_SOUTH;



  public static void main(String[] args) {
    //declaring variables for storing input
    String name1, name2;
    int age1, age2, petsAgreement;
    char pets1, pets2;
    float salary1, salary2, salaryDiffer;
    double prefDist1, prefDist2;
    //declaring variables for calculation
    double long1, lat1, long2, lat2, distBetween;
	double distRemain1, distRemain2; 
	double distFact1 = 0, distFact2 = 0, totDistFact, compatible;
    final double latFact = (37.89/(45.5374-44.96257));
    final double longFact = (86.70/(76.35398-75.24643));
    //random coordinates
    long1 = -75;//(1.10755*Math.random())-76.35398;
    long2 = -75;//(1.10755*Math.random())-76.35398;
    lat1 = 45;//(0.57477*Math.random())+44.96257;
    lat2 = 45;//(0.57477*Math.random())+44.96257;

    //person 1 input
    System.out.println("Person 1: Enter your details");
    System.out.println("State your name: ");
    name1 = In.getString();
    System.out.println("State your age: ");
    age1 = In.getInt();
    //age check
    if (age1 < 16) {
      System.out.println("\n\nResults:\nSorry, but one/both of you are too young for this application.");
      //using this method because it's easier
      System.exit(0);
    }
    System.out.println("Do you like pets? (Y/N): ");
    pets1 = In.getChar();
    //Pets check
    if (pets1 != 'Y' && pets1 != 'y'){
      if (pets1 != 'N' && pets1 != 'n') {
        System.out.println("Sorry, but that value is not accepted.");
        System.exit(0);
      }
    }
    System.out.println("What is your approximate annual salary? ");
    salary1 = In.getFloat();
    //Salary check
    if (salary1 < 0) {
      System.out.println("Sorry, but that value is not accepted.");
      System.exit(0);
    }
    System.out.println("How far are you ok with travelling to find love (km)? ");
    prefDist1 = In.getDouble();
    //Distance check
     if (prefDist1 < 0) {
      System.out.println("Sorry, but that value is not accepted.");
      System.exit(0);
    }

    //person 2 input
    System.out.println("\nPerson 2: Enter your details");
    System.out.println("State your name: ");
    name2 = In.getString();
    System.out.println("State your age: ");
    age2 = In.getInt();
    //age check
    if (age2 < 16) {
      System.out.println("Sorry, but one/both of you are too young for this application.");
      System.exit(0);
    }
    System.out.println("Do you like pets? (Y/N): ");
    pets2 = In.getChar();
    //pets check
    if (pets2 != 'Y' && pets2 != 'y'){
      if (pets2 != 'N' && pets2 != 'n') {
        System.out.println("Sorry, but that value is not accepted.");
        System.exit(0);
      }
    } 
    System.out.println("What is your approximate annual salary? ");
    salary2 = In.getFloat();
    //Salary check
    if (salary2 < 0) {
      System.out.println("Sorry, but one/both values are not accepted.");
      System.exit(0);
    }
    System.out.println("How far are you ok with travelling to find love (km)? ");
    prefDist2 = In.getDouble();
    //Distance check
     if (prefDist2 < 0) {
      System.out.println("Sorry, but one/both values are not accepted.");
      System.exit(0);
    }

    //calculations
    salaryDiffer = Math.abs(salary1-salary2);
    //check if both users like pets, and stores info for end compatibility (note: we don't check if one is capital and one is lowercase)
    petsAgreement = 1;
    if (pets1!=pets2) {
      petsAgreement = 0;
    }
    //calculating dist between one point to another
    distBetween = Math.sqrt(Math.pow(longFact*(long1-long2), 2)+(Math.pow(latFact*(lat1-lat2), 2)));
    //check if coordinates are the same
    if (distBetween == 0) {
      System.out.println("Congrats! Either both of you are right next to each other or are the same person!"); //normally would end program bc 0km distance isn't normal
    }
    distFact1 = 0;
    distFact2 = 0;
    //calculating the difference between the preferred dist and actual dist, and getting the total distance factor
    distRemain1 = distBetween-prefDist1;
    distRemain2 = distBetween-prefDist2;
    if (distRemain1>0) {
      distFact1 = 0.001*Math.pow(distRemain1,2);
    }
    if (distRemain2>0) {
      distFact2 = 0.001*Math.pow(distRemain2,2);
    }
    totDistFact = 20/Math.sqrt(distFact1+distFact2+1);
    //calculating end compatibility
    compatible = 50/(0.5*Math.abs(age1-age2)+1)+10*petsAgreement+20/Math.sqrt(0.00003*salaryDiffer+1)+totDistFact;

    //output: compatibility results
    System.out.println("\nResults:");
    System.out.printf("%s and %s are %.0f%% compatible and live %.1f km away from each other.\n",name1,name2,compatible,distBetween);
    //salary details in terms of compatibility
    if (salaryDiffer != 0) {
      System.out.printf("%s makes $%,.2f more than %s.\n",name1,salaryDiffer,name2);
    }
    else {
      System.out.printf("%s makes the same as %s.\n",name1,name2);
    }
    //tells if both users think pets are awesome or not
    if (petsAgreement == 0) {
      System.out.println("\nYou disagree on pets.");
    }
    else if (petsAgreement == 1) {
      System.out.println("\nYou agree on pets.");
    }
  }
}

//this WOULD have been be the angles
//Math.acos(longFact*(long1-long2)/distBetween);
//Math.acos(latFact*(lat1-lat2)/distBetween);