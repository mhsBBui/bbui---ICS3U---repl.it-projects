//repetition: BOWTIE
//bryan B.
//3.3.2021
//this program will print out a bow tie with height input being an odd positive int greater than or equal to 5

class Main {
  public static void main(String[] args) {
    //declaring variable
    int userInH;
    //check if input is valid
    do {
      System.out.println("Enter height:");
      userInH = In.getInt();
      if (userInH<5 || userInH%2==0) {
        System.out.println("Invalid entry.\nMust be an odd integer 5 or greater.\nTry again.");
      }
    } while(userInH<5 || userInH%2==0);

    //for loop: top
    for (int count = 2; count<=userInH/2+2; count++) {
      //beginning and end always will start with one * and one *\n
      System.out.print("*");
      //count would have been 3 by then so count-2 instead of -1
      for (int count2 = userInH-(count-2); count2<=userInH-1; count2++) {
        System.out.print("**");
      }
      for (int count3 = count*2-3; count3<=userInH-1; count3++) {
        System.out.print("  ");
      }
      //printing ** again but on the other side
      for (int count4 = userInH-(count-2); count4<=userInH-1; count4++) {
        System.out.print("**");
        if (count4==userInH-1) {
          System.out.print("*\n");
        }
      }
      //since count-2 is 11 and exceeds 10, one-time check to print for the first line (too difficult to adjust personally)
      if (count==2) {
        System.out.print("*\n");
      }
    }
    //for loop: bottom (reversed copy+paste, only initialization changed)
    for (int count = 2; count<=userInH/2+1; count++) {
      System.out.print("*");
      for (int count2 = count+userInH/2; count2<=userInH-1; count2++) {
        System.out.print("**");
      }
      for (int count3 = userInH-(count*2-2); count3<=userInH-1; count3++) {
        System.out.print("  ");
      }
      for (int count4 = count+userInH/2; count4<=userInH-1; count4++) {
        System.out.print("**");
        if (count4==userInH-1) {
          System.out.print("*\n");
        }
      } 
    }
    //the end
    System.out.print("*");
  }
}